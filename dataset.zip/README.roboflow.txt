
GI actions - v1 2021-08-11 4:24pm
==============================

This dataset was exported via roboflow.ai on August 11, 2021 at 1:24 PM GMT

It includes 3510 images.
Actions are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Randomly crop between 0 and 10 percent of the image
* Random brigthness adjustment of between -20 and +20 percent


